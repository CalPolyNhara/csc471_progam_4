README

the dino.obj does not have normals. 

this file is in the resources file.

The dino is technically a dilophosaurus.

This project was not fun at all. :(