README

Here is my readme. I'm not sure what you wanted added
to it, so I am going to do a small explanation:

the spline is supposed to go around and focus on the dinosasur

beyond that the mouse scrolling works 360 degrees horizontally
and up to +- 89 degrees vertically. 

I added a skybox of a stormy sky.